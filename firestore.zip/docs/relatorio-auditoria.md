# Relatório de Auditoria de Código — `tertoct`
**Data:** 14 de Maio de 2026  
**Arquivos analisados:** 22 arquivos (proxy, firestore rules, utils, validations, mappers, observability, testes)  
**Stack:** Next.js 16 · Firebase/Firestore · TypeScript · Tailwind CSS 4 · Zod 4

---

## Índice
1. [Resumo Executivo](#resumo)
2. [Segurança — Crítico](#segurança-crítico)
3. [Segurança — Alto](#segurança-alto)
4. [Segurança — Médio](#segurança-médio)
5. [Rate Limiting](#rate-limiting)
6. [Cache & Performance](#cache--performance)
7. [Redundância & Código Morto](#redundância--código-morto)
8. [Dependências](#dependências)
9. [Configuração & Build](#configuração--build)
10. [Qualidade de Testes](#qualidade-de-testes)
11. [Tabela de Prioridades](#tabela-de-prioridades)

---

## 1. Resumo Executivo

O projeto é um sistema de gestão de academia (check-ins, planos, pagamentos) com arquitetura Next.js + Firebase bem estruturada. A base de código apresenta boas práticas em várias áreas — regras Firestore detalhadas, separação de responsabilidades, testes unitários cobrindo cenários relevantes. Porém, foram identificados **5 problemas críticos/altos de segurança**, ausência completa de **rate limiting**, e diversas duplicações de lógica que aumentam o risco de bugs ao longo do tempo.

---

## 2. Segurança — Crítico 🔴

### 2.1 CSP com `unsafe-inline` + `unsafe-eval` anula proteção XSS — e o nonce nunca é usado

**Arquivo:** `src/proxy.ts` — função `buildCsp()`

```typescript
// PROBLEMA: unsafe-inline e unsafe-eval tornam o CSP ineficaz contra XSS
`script-src 'self' 'unsafe-inline' 'unsafe-eval' https://apis.google.com ...`
```

O middleware gera um nonce (`generateNonce()`) e o propaga corretamente como header `x-nonce`, **mas o nonce nunca é inserido no CSP**. A presença de `'unsafe-inline'` faz o browser ignorar qualquer nonce de qualquer forma. O resultado é um CSP que transmite falsa sensação de segurança enquanto permite qualquer script inline.

**Correção:**
```typescript
function buildCsp(nonce: string): string {
  return [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}' https://apis.google.com https://accounts.google.com`,
    // Remover 'unsafe-inline' e 'unsafe-eval'
    ...
  ].join("; ");
}

// Em withSecurityHeaders, passar o nonce:
response.headers.set("Content-Security-Policy", buildCsp(nonce));
```

> **Nota:** remover `unsafe-eval` pode quebrar funcionalidades que dependem de `eval()`. Auditar código e dependências antes.

---

### 2.2 Coleção `feedbacks` publicamente legível sem autenticação

**Arquivo:** `firestore.rules`

```javascript
match /feedbacks/{feedbackId} {
  allow read: if true;  // ← qualquer pessoa na internet lê todos os feedbacks
  ...
}
```

Qualquer pessoa, sem login, pode listar todos os feedbacks de alunos. Dependendo do conteúdo, isso expõe dados pessoais e pode violar LGPD.

**Correção:**
```javascript
allow read: if isSignedIn() && (
  resource.data.userId == request.auth.uid || isCoach()
);
```

---

### 2.3 Bloco `classes` duplicado com regras conflitantes

**Arquivo:** `firestore.rules`

Existem **dois** blocos `match /classes/{classId}` no arquivo:

```javascript
// Bloco 1 (~linha 87) — permite alunos autenticados lerem
match /classes/{classId} {
  allow read: if isSignedIn();
  allow create, update, delete: if isCoach();
}

// Bloco 2 (~linha final, "futuras coleções") — mais restritivo
match /classes/{classId} {
  allow read: if isCoach();   // ← substitui silenciosamente o bloco 1
  allow create, update, delete: if isCoach();
}
```

No Firestore, quando há dois `match` para o mesmo caminho, **a regra mais permissiva prevalece** — mas o comportamento é ambíguo e dependente da versão das rules. Isso é uma armadilha de manutenção crítica: o segundo bloco deveria ser removido ou fundido.

**Correção:** Remover o segundo bloco da seção "futuras coleções".

---

### 2.4 `firebase-admin` como devDependency em produção

**Arquivo:** `package.json`

```json
"devDependencies": {
  "firebase-admin": "^12.7.0"  // ← ERRADO: é usado em API routes de produção
}
```

O Firebase Admin SDK (usado em rotas `/api/private/*`, scripts de seed e notificações) está declarado como devDependency. Em deploys que rodam `npm install --production` (Vercel, Docker etc.), o pacote **não será instalado** e a aplicação falhará em runtime.

**Correção:** Mover para `dependencies`.

---

### 2.5 `validations/index.ts` importa arquivos inexistentes

**Arquivo:** `src/lib/validations/index.ts`

```typescript
export * from './user';    // ← arquivo não existe no projeto
export * from './plan';    // ← arquivo não existe no projeto
export * from './checkIn'; // ← arquivo não existe no projeto
```

Isso causa **erro de build** imediato. O arquivo está na pasta mas referencia módulos ausentes. Ou os arquivos foram deletados e as exportações ficaram, ou nunca foram criados.

**Correção:** Criar os arquivos faltantes com schemas Zod (adequado dado que Zod é uma dependência) ou remover as exportações mortas.

---

## 3. Segurança — Alto 🟠

### 3.1 Headers de segurança ausentes: HSTS e Permissions-Policy

**Arquivo:** `src/proxy.ts` — `withSecurityHeaders()`

Os headers aplicados são bons, mas faltam dois importantes:

| Header ausente | Risco |
|---|---|
| `Strict-Transport-Security` | Sem HSTS, um atacante MITM pode fazer downgrade para HTTP |
| `Permissions-Policy` | Sem restrição de features do browser (câmera, microfone, geolocation) |

**Correção:**
```typescript
response.headers.set(
  "Strict-Transport-Security",
  "max-age=63072000; includeSubDomains; preload"
);
response.headers.set(
  "Permissions-Policy",
  "camera=(), microphone=(), geolocation=()"
);
```

---

### 3.2 `trackStatusAnomaly` — detector de anomalias quebrado em serverless

**Arquivo:** `src/lib/observability/serverObservability.ts`

```typescript
const statusEvents = new Map<string, number[]>(); // ← memória do processo
```

Em ambientes serverless (Vercel Functions, Edge Runtime), cada invocação pode ser um processo novo. O Map é reiniciado a cada cold start, então o alerta de `ALERT_THRESHOLD = 20` nunca dispara de forma confiável em produção.

Adicionalmente, o Map **nunca é limpo**: `statusEvents.set(key, recent)` atualiza os valores mas jamais chama `.delete(key)`. Com dezenas de rotas sob ataque, a memória cresce indefinidamente até o processo ser reciclado.

**Correção:** Usar Redis/Upstash para persistência entre invocações, ou pelo menos adicionar limpeza:
```typescript
if (recent.length === 0) {
  statusEvents.delete(key);
} else {
  statusEvents.set(key, recent);
}
```

---

### 3.3 `isCurrentUserActive` — documento inexistente = usuário ativo

**Arquivo:** `firestore.rules`

```javascript
function isCurrentUserActive() {
  return !exists(/databases/$(database)/documents/users/$(request.auth.uid)) ||
    !('active' in get(...).data) ||
    get(...).data.active == true;
}
```

Se o documento do usuário **não existir**, a função retorna `true` (ativo). Isso significa que um usuário autenticado cuja conta ainda não foi provisionada pode tentar criar check-ins. Combinado com uma race condition no signup, pode haver uma janela de exploração.

**Correção:**
```javascript
function isCurrentUserActive() {
  return exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
    get(...).data.get('active', true) == true;
}
```

---

## 4. Segurança — Médio 🟡

### 4.1 `sanitize.ts` permite `<a href>` sem proteção extra explícita

**Arquivo:** `src/lib/validations/sanitize.ts`

```typescript
ALLOWED_ATTR: ['href', 'target', 'rel'],
```

DOMPurify bloqueia `javascript:` por padrão, então isso é tecnicamente seguro. Porém, `target="_blank"` sem `rel="noopener noreferrer"` abre vetor de tabnapping. Considerar forçar `rel`:

```typescript
ALLOWED_ATTR: ['href', 'rel'],
// Remover 'target' ou forçar rel="noopener noreferrer" no output
```

### 4.2 `ALLOWED_ORIGINS` sem validação de formato

**Arquivo:** `src/lib/security/origin.ts`

A env var `ALLOWED_ORIGINS` é lida e splitada por vírgula sem validação de formato. Uma entrada malformada (ex: `http://evil.com , *`) não causa erro, apenas entra como string no Set. Adicionar validação de URL ao popular o Set.

---

## 5. Rate Limiting 🚦

**Não existe nenhuma implementação de rate limiting no projeto.**

O middleware (`proxy.ts`) realiza autenticação e autorização, mas **qualquer IP pode fazer requisições ilimitadas** a qualquer endpoint, incluindo:

- `/api/private/*` — protegida apenas por token, mas um token válido pode ser usado para flood
- Endpoints públicos (ex: listagem de planos) — sem throttle algum

### O que implementar

| Endpoint | Proteção recomendada |
|---|---|
| Login / emissão de token | 5 req/min por IP |
| Check-in POST | 10 req/min por usuário |
| APIs privadas coach/admin | 100 req/min por usuário |
| APIs públicas | 60 req/min por IP |

### Como implementar (sem biblioteca externa)

O Next.js middleware é o local ideal. Com Upstash Redis (integração nativa Vercel):

```typescript
// src/lib/rateLimit.ts
import { Redis } from '@upstash/redis';

const redis = Redis.fromEnv();

export async function rateLimit(key: string, limit: number, windowSec: number) {
  const count = await redis.incr(key);
  if (count === 1) await redis.expire(key, windowSec);
  return count <= limit;
}
```

Alternativa sem Redis: usar `@vercel/kv` ou middleware de edge com headers `X-RateLimit-*`.

---

## 6. Cache & Performance ⚡

### 6.1 Nenhuma estratégia de cache visível

Não foi encontrado nenhum uso de:
- `next/cache` com `revalidate` (ISR)
- `unstable_cache` para queries Firestore
- Headers `Cache-Control` nas respostas de API
- SWR ou React Query no cliente

Para dados semi-estáticos como planos e turmas, uma estratégia de cache reduziria drasticamente as leituras do Firestore (custo e latência).

**Sugestão para dados de planos (raramente mudam):**
```typescript
import { unstable_cache } from 'next/cache';

export const getPlans = unstable_cache(
  async () => { /* query firestore */ },
  ['plans'],
  { revalidate: 300 } // 5 minutos
);
```

### 6.2 Regras Firestore com múltiplos `get()` ao mesmo documento

**Arquivo:** `firestore.rules` — regra de create em `checkins`

A regra de criação de check-in chama `get(/databases/.../users/$(request.auth.uid))` **quatro vezes** separadas. Embora o Firestore faça cache internamente por request, o código é desnecessariamente verboso e frágil. Extrair para variável local nas rules:

```javascript
allow create: if isStudent() && 
  isCurrentUserActive() && {
  let userData = get(/databases/$(database)/documents/users/$(request.auth.uid)).data;
  // usar userData.planId, userData.paymentDueDay etc.
  ...
}
```

### 6.3 `checkinCounters` — leituras redundantes por check-in

Cada operação de check-in lê: documento do usuário, documento do plano, counter do usuário, counter da turma. Avaliar consolidar em um único documento de estado ou usar Cloud Functions para manter contadores, reduzindo as transações do cliente.

---

## 7. Redundância & Código Morto 🧹

### 7.1 `startOfWeek` duplicada em dois arquivos

**Arquivos:** `src/lib/utils/date.ts` e `src/lib/utils/weekFilters.ts`

```typescript
// date.ts
export function startOfWeek(date: Date): Date { ... }

// weekFilters.ts
export function getWeekStart(date: Date = new Date()): Date {
  // algoritmo idêntico ao startOfWeek
}
```

As duas funções implementam o mesmo algoritmo (segunda-feira como início da semana). `weekFilters.ts` também duplica a lógica de formatação de chave de data já presente em `dateKey.ts`.

**Correção:** `weekFilters.ts` deve importar de `date.ts` e `dateKey.ts`.

### 7.2 Conversão de Timestamp Firestore duplicada em 3 lugares

A lógica de converter `Timestamp | { seconds, toDate }` para `Date` existe em:

| Arquivo | Função |
|---|---|
| `src/lib/firestore/mappers.ts` | `toDateMaybe()` (privada) |
| `src/lib/utils/date.ts` | `toDate()` (exportada) |
| `src/lib/utils/checkins.ts` | inline com `any` (sem tipagem) |

`toDateMaybe` em `mappers.ts` deveria simplesmente importar `toDate` de `date.ts`. E `checkins.ts` deveria usar `toDate` em vez de reimplementar com `any`.

### 7.3 `checkins.ts` desabilita ESLint desnecessariamente

**Arquivo:** `src/lib/utils/checkins.ts`

```typescript
/* eslint-disable  @typescript-eslint/no-explicit-any */
```

O `any` só é necessário porque a conversão de timestamp é feita inline. Usando `toDate()` de `date.ts`, o `any` some completamente.

### 7.4 `buildCsp()` como função quando deveria ser constante

**Arquivo:** `src/proxy.ts`

`buildCsp()` é chamada a cada request mas retorna sempre o mesmo valor (não usa o nonce, como identificado em 2.1). Enquanto o nonce não é usado na CSP, isso é desperdício de ciclos. Após corrigir o nonce, `buildCsp(nonce: string)` faz sentido como função, mas o resto poderia ser cacheado como template.

### 7.5 `userDoc` importado em `firebase.ts` mas arquivo referenciado não existe no zip

**Arquivo:** `src/lib/firebase.ts` re-exporta de `./firebase/client` — este arquivo não está no zip. Se foi omitido intencionalmente, ok. Caso contrário, indica arquivo perdido.

---

## 8. Dependências 📦

### 8.1 `react-slick` + `slick-carousel` — legados e com problemas de acessibilidade

```json
"react-slick": "^0.31.0",
"slick-carousel": "^1.8.1"
```

Ambos os pacotes estão estagnados (último release relevante em 2020), têm problemas conhecidos de acessibilidade (aria roles incorretos), e exigem importação de CSS global do jQuery-era. Para um projeto com Tailwind 4, são outliers arquiteturais.

**Substituição recomendada:** `embla-carousel-react` (zero deps, acessível, 15kb vs 80kb do slick).

### 8.2 `eslint-config-prettier` + `eslint-plugin-prettier` — possivelmente redundantes

Dependendo da config ESLint, ter ambos pode causar conflitos. `eslint-config-prettier` desativa regras de formatação do ESLint. `eslint-plugin-prettier` adiciona Prettier como regra ESLint. Em projetos com Next.js 16 (ESLint 9 flat config), a combinação precisa ser revisada.

### 8.3 `@firebase/rules-unit-testing` instalado mas sem testes de rules no projeto

A biblioteca está em devDependencies mas não há arquivos `*.rules.test.*` no zip. Se os testes de rules existem em outro diretório não incluído, ignorar. Caso contrário, a dependência é ociosa.

### 8.4 Versões — verificar compatibilidade

| Pacote | Versão | Observação |
|---|---|---|
| `next` | `16.1.6` | Versão muito nova — verificar breaking changes |
| `firebase` | `^12.9.0` | Versão muito nova — verificar breaking changes |
| `zod` | `^4.3.6` | Zod 4 tem API diferente de v3 — confirmar compatibilidade |
| `jest` | `^30.3.0` | Versão muito nova — verificar compatibilidade com ts-jest |
| `@types/jest` | `^30.0.0` | Ok se alinhado com jest |

---

## 9. Configuração & Build ⚙️

### 9.1 Script `lint` sem alvo — não linta nada

**Arquivo:** `package.json`

```json
"lint": "eslint"
```

`eslint` sem argumento de caminho não processa nenhum arquivo e retorna sucesso silenciosamente. O CI verde não garante que o código foi lintado.

**Correção:**
```json
"lint": "eslint src --ext .ts,.tsx"
// ou com ESLint 9 flat config:
"lint": "eslint ."
```

### 9.2 Ausência de validação de variáveis de ambiente no startup

Nenhum arquivo no projeto valida se as variáveis de ambiente obrigatórias estão presentes na inicialização. Um deploy sem `ALLOWED_ORIGINS` ou credenciais do Firebase falha em runtime de forma opaca.

**Sugestão:** Adicionar `src/lib/env.ts` com schema Zod:
```typescript
import { z } from 'zod';

const envSchema = z.object({
  NEXT_PUBLIC_FIREBASE_PROJECT_ID: z.string().min(1),
  FIREBASE_ADMIN_PRIVATE_KEY: z.string().min(1),
  ALLOWED_ORIGINS: z.string().optional(),
  NODE_ENV: z.enum(['development', 'production', 'test']),
});

export const env = envSchema.parse(process.env);
```

### 9.3 `next.config.js` ausente no zip

Impossível avaliar: otimização de imagens (`next/image`), redirecionamentos, headers de segurança via config (alternativa/complemento ao middleware), bundle analyzer, configurações de transpile.

### 9.4 Ausência de `tsconfig.json` e `.eslintrc`

Igualmente ausentes. Impossível auditar configurações de paths, strict mode TypeScript, plugins ESLint ativos.

---

## 10. Qualidade de Testes 🧪

### O que está bom ✅
- `proxy.test.ts` cobre os 5 cenários principais (401, 403, redirect, nonce, token inválido)
- `payment.test.ts` cobre bem o fallback de `paymentValidUntil` e o comportamento legacy
- `studentFilter.test.ts` testa combinações de filtros
- `date.test.ts` testa casos de borda (domingo, sábado, mutação de objeto)

### O que está faltando ❌

| Área | Testes ausentes |
|---|---|
| `origin.ts` | Nenhum teste para `isTrustedMutationRequest` |
| `weekFilters.ts` | Nenhum teste |
| `checkins.ts` | Nenhum teste para `aggregateCheckinsByClass` |
| `observability` | Nenhum teste para `trackStatusAnomaly` |
| Firestore rules | `@firebase/rules-unit-testing` instalado mas sem testes |
| `sanitize.ts` | Nenhum teste para `sanitizeHtml`/`stripHtml` |
| `time.ts` | Nenhum teste para `parseHHmm`/`formatHHmm` |
| `dateKey.ts` | Nenhum teste para `getDateKeyForOffset`/`utcDateAtLocalTime` |

As funções de data (`dateKey.ts`) envolvem lógica de timezone que é especialmente propensa a bugs — são justamente as mais importantes de testar.

---

## 11. Tabela de Prioridades

| # | Problema | Severidade | Esforço | Arquivo |
|---|---|---|---|---|
| 1 | CSP com `unsafe-inline`/`unsafe-eval`, nonce não usado | 🔴 Crítico | Médio | `proxy.ts` |
| 2 | `feedbacks` publicamente legível | 🔴 Crítico | Baixo | `firestore.rules` |
| 3 | Bloco `classes` duplicado com conflito | 🔴 Crítico | Baixo | `firestore.rules` |
| 4 | `firebase-admin` em devDependencies | 🔴 Crítico | Baixo | `package.json` |
| 5 | `validations/index.ts` importa arquivos inexistentes | 🔴 Crítico | Médio | `validations/index.ts` |
| 6 | Ausência total de rate limiting | 🟠 Alto | Alto | middleware |
| 7 | HSTS e Permissions-Policy ausentes | 🟠 Alto | Baixo | `proxy.ts` |
| 8 | `trackStatusAnomaly` quebrado em serverless + memory leak | 🟠 Alto | Médio | `serverObservability.ts` |
| 9 | `isCurrentUserActive` aceita doc inexistente como ativo | 🟠 Alto | Baixo | `firestore.rules` |
| 10 | Nenhuma estratégia de cache para dados Firestore | 🟡 Médio | Médio | global |
| 11 | `startOfWeek` duplicada em dois arquivos | 🟡 Médio | Baixo | `date.ts` / `weekFilters.ts` |
| 12 | Conversão de Timestamp duplicada em 3 lugares | 🟡 Médio | Baixo | `mappers.ts` / `checkins.ts` |
| 13 | Script `lint` sem alvo | 🟡 Médio | Baixo | `package.json` |
| 14 | Sem validação de env vars no startup | 🟡 Médio | Baixo | novo arquivo |
| 15 | `react-slick` + `slick-carousel` legados | 🟢 Baixo | Alto | `package.json` |
| 16 | `eslint-disable any` desnecessário em `checkins.ts` | 🟢 Baixo | Baixo | `checkins.ts` |
| 17 | `@firebase/rules-unit-testing` sem testes de rules | 🟢 Baixo | Alto | `firestore.rules` |
| 18 | Falta de testes: `origin`, `weekFilters`, `dateKey` | 🟢 Baixo | Médio | vários |

---

*Relatório gerado por análise estática manual de todos os 22 arquivos do pacote. Não foram executados os scripts nem testado o comportamento em runtime.*
