# architecture.md — tertoct

> Gerado a partir do código real em `src/`. Zero invenção.

---

## Stack

- **Framework**: Next.js (App Router)
- **Auth**: Firebase Authentication (Google) + cookie HTTPOnly (`authToken`)
- **Banco**: Cloud Firestore (client SDK no frontend, Admin SDK nas API routes)
- **Middleware**: `src/proxy.ts` (Next.js middleware — roda em edge antes de toda request)
- **Roles**: `admin` | `coach` | `student`

---

## Estrutura de pastas

```
src/
├── app/                        # Rotas Next.js
│   ├── api/auth/               # Endpoints públicos de autenticação
│   │   ├── cookie/route.ts     # POST/DELETE — salva/remove cookie de sessão
│   │   └── verify/route.ts     # POST — verifica token Firebase
│   ├── api/private/            # Endpoints protegidos (requerem cookie válido)
│   │   ├── checkins/route.ts   # POST — cria check-in (apenas student)
│   │   ├── classes/route.ts    # POST — cria turma (coach/admin)
│   │   ├── classes/[classId]/  # PATCH/DELETE — edita/remove turma
│   │   ├── plans/route.ts      # POST — cria plano (coach/admin)
│   │   ├── plans/[planId]/     # PATCH/DELETE — edita/remove plano
│   │   ├── plans/[planId]/toggle/ # POST — ativa/desativa plano
│   │   ├── users/[userId]/     # PATCH — ações no usuário (coach/admin)
│   │   ├── feedback/route.ts   # POST — cria feedback
│   │   ├── feedback/[feedbackId]/ # DELETE — remove feedback
│   │   └── clearRateLimits/    # POST — limpa rate limits (admin)
│   └── dashboard/page.tsx      # Página do dashboard (roteada por role)
├── components/
│   ├── auth/AuthProvider.tsx   # Context de auth client-side
│   ├── dashboard/
│   │   ├── StudentDashboard.tsx    # Dashboard do aluno
│   │   ├── CoachDashboard.tsx      # Dashboard do coach/admin
│   │   ├── student/
│   │   │   ├── CheckinTab.tsx      # Aba de check-in do aluno
│   │   │   └── OverviewTab.tsx     # Aba de resumo do aluno
│   │   └── coach/
│   │       ├── StudentsTab.tsx     # Lista e gestão de alunos
│   │       ├── PlansTab.tsx        # CRUD de planos
│   │       ├── ClassesTab.tsx      # CRUD de turmas
│   │       ├── CheckinsTab.tsx     # Histórico de check-ins
│   │       ├── CheckinHistoryModal.tsx # Modal de histórico por aluno
│   │       ├── OverviewTab.tsx     # Visão geral do coach
│   │       ├── ExpirationsTab.tsx  # Alunos com pagamento vencendo
│   │       └── ProfessorsTab.tsx   # Gestão de coaches
│   ├── landing/
│   │   ├── PlansSection.tsx    # Seção de planos na landing
│   │   ├── CoachesSection.tsx  # Seção de coaches na landing
│   │   └── FeedbackWall.tsx    # Mural de feedbacks públicos
│   └── ui/                     # Componentes genéricos (BarChart, StatusBadge, PageLoader)
├── lib/
│   ├── auth/                   # Toda lógica de autenticação server-side
│   ├── firestore/              # Refs e mappers do Firestore
│   ├── validations/            # Schemas Zod de validação
│   ├── utils/                  # Utilitários (data, pagamento, filtros)
│   ├── observability/          # Logs e tracking de erros
│   └── types.ts                # Tipos globais
├── services/                   # Camada cliente → Firestore/API
├── security/                   # Testes de regras do Firestore
└── proxy.ts                    # Middleware Next.js (edge)
```

---

## Firestore — Coleções

Fonte: `src/lib/firestore/refs.ts` e `src/lib/types.ts`

| Coleção | Campos principais |
|---|---|
| `users` | `name`, `email`, `role`, `planId`, `active`, `createdAt`, `paymentDueDay`, `monthlyPaymentPaid`, `paymentValidUntil`, `phone` |
| `publicProfiles` | `name`, `email`, `role`, `photoURL`, `active`, `bio` |
| `plans` | `name`, `price`, `classesPerWeek`, `description`, `active` |
| `classes` | `name`, `startTime` (HH:mm), `checkinDeadlineTime` (HH:mm), `capacity`, `utcOffsetMinutes`, `active`, `createdBy`, `createdAt` |
| `checkins` | `userId`, `planId`, `classId`, `classDateKey` (YYYY-MM-DD), `className`, `classStartTime`, `createdAt`, `weekKey` |
| `checkinCounters` | `userId`, `weekKey`, `count` — ID: `{userId}_{weekKey}` |
| `classCheckinCounters` | `classId`, `classDateKey`, `count` — ID: `{classId}_{dateKey}` |
| `_rateLimits` | `key`, `count`, `windowStart`, `resetAt` — rate limiting via Firestore |
| `feedbacks` | `userId`, `userName`, `message`, `createdAt` |

---

## Auth — Fluxo completo

```
Login Google (client)
  → Firebase Authentication emite idToken
  → POST /api/auth/cookie (token no body)
    → verifyToken() valida token com Firebase Admin
    → checkRateLimit() — limite por clientId
    → cookie httpOnly "authToken" setado (maxAge: 1h)

Request em rota protegida
  → proxy.ts intercepta
    → lê "authToken" do cookie
    → verifyToken() valida
    → isAuthorizedForPath() checa role vs PATH_ROLE_RULES
    → passa ou retorna 401/403

API route /api/private/*
  → getPrivateRouteContext()
    → lê cookie → verifyToken()
    → lê role do token ou fallback no Firestore users/{uid}.role
    → retorna { session, role }
  → requireRole() checa role permitida para a rota
```

### Arquivos de auth (`src/lib/auth/`)

| Arquivo | Responsabilidade |
|---|---|
| `cookies.ts` | Nome do cookie (`authToken`) e opções (httpOnly, secure, sameSite, maxAge 1h) |
| `verifyToken.ts` | Verifica idToken com Firebase Admin |
| `privateRoute.ts` | `getPrivateRouteContext()` + `requireRole()` — usado em todas as API routes privadas |
| `authorization.ts` | `isAuthorizedForPath()` — PATH_ROLE_RULES por prefixo de URL |
| `rbac.ts` | `requireCustomClaim()`, `requireRoles()` — validação de claims no token |
| `clientIdentifier.ts` | Gera fingerprint de cliente (IP + user-agent) com SHA-256 para rate limiting |
| `rateLimit.ts` | Rate limiting via Firestore `_rateLimits`, fail-closed por padrão |
| `rateLimitKey.ts` | `buildAuthRateLimitKey()` — chave composta para rate limit de auth |
| `rateLimitMemory.ts` | Rate limiter in-memory (alternativo ao Firestore) |
| `admin.ts` | Inicializa Firebase Admin SDK (Firestore + Auth) |

---

## Services (`src/services/`) — camada cliente

| Arquivo | Funções principais |
|---|---|
| `checkinService.ts` | `createCheckIn()`, `fetchCheckinsByUser()`, `listenCheckinsByUser()` |
| `planService.ts` | `createPlan()`, `updatePlan()`, `deletePlan()`, `togglePlanActive()` |
| `classService.ts` | `listenActiveClasses()`, `fetchClassCountersForDate()`, `createGymClass()`, `updateGymClass()`, `deleteGymClass()` |
| `dashboardService.ts` | `listenPlans()`, `listenStudents()`, `listenCoaches()`, `listenCheckinCountsSince()`, `fetchRecentCheckinsSince()` |
| `userService.ts` | `assignPlan()`, `setPaymentDay()`, `togglePayment()`, `toggleUserActive()`, `updateUserPhone()` |
| `feedbackService.ts` | `createFeedback()`, `deleteFeedback()`, `fetchPublicFeedbacks()`, `listenMyFeedbacks()` |
| `landingService.ts` | `fetchActivePlans()`, `fetchActiveCoaches()` — dados públicos da landing |
| `userProfileService.ts` | Gestão de perfil do usuário autenticado |
| `plansQueryService.ts` | Query auxiliar de planos |

---

## Check-in — Regras de negócio (fonte: `/api/private/checkins/route.ts`)

Tudo em **transação Firestore** — sem condições de corrida:

1. Usuário deve ter `planId` igual ao enviado e plano `active: true`
2. Turma deve estar `active: true`
3. Horário atual deve ser **antes** de `checkinDeadlineTime` da turma
4. ID do check-in é determinístico: `{userId}_{classId}_{dateKey}` — previne duplicata
5. `classCheckinCounters` verifica capacidade da turma por dia
6. `checkinCounters` verifica limite semanal do plano (`classesPerWeek`)

---

## Usuário — Ações via API (`/api/private/users/[userId]` PATCH)

Discriminated union de actions:

| action | O que faz |
|---|---|
| `assign-plan` | Vincula planId ao aluno; `planId: null` desativa e limpa pagamento |
| `set-payment-day` | Define dia de vencimento mensal |
| `toggle-payment` | Marca pago/não-pago; calcula `paymentValidUntil` até próximo vencimento |
| `toggle-active` | Ativa/desativa usuário; sincroniza `publicProfiles` se for coach/admin |
| `update-phone` | Atualiza telefone |

---

## Proxy / Middleware (`src/proxy.ts`)

Roda em **edge** antes de toda request:

- Injeta headers de segurança (CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy)
- Gera nonce por request
- Rotas protegidas: `/dashboard/*` e `/api/private/*`
- Verifica `authToken` cookie → `verifyToken()` → `isAuthorizedForPath()`
- Redireciona para `/` se não autenticado (web) ou 401 (API)
- Retorna 403 se autenticado mas sem role suficiente
